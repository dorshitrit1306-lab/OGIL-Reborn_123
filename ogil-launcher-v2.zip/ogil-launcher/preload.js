const { contextBridge, ipcRenderer } = require('electron');

contextBridge.exposeInMainWorld('launcher', {
  api: (req) => ipcRenderer.invoke('api:request', req),
  getSettings: () => ipcRenderer.invoke('settings:get'),
  saveSettings: (s) => ipcRenderer.invoke('settings:set', s),
  libraryList: () => ipcRenderer.invoke('library:list'),
  libraryAdd: (p) => ipcRenderer.invoke('library:add', p),
  libraryRemove: (id) => ipcRenderer.invoke('library:remove', id),
  libraryLaunch: (id) => ipcRenderer.invoke('library:launch', id),
  pickFile: () => ipcRenderer.invoke('dialog:pick'),
  openExternal: (url) => ipcRenderer.invoke('shell:open', url),
  minimize: () => ipcRenderer.send('win:minimize'),
  close: () => ipcRenderer.send('win:close')
});
