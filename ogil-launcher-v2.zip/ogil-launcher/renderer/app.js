'use strict';

const L = window.launcher;

const ROLE_LABEL = { owner: 'בעלים', admin: 'מנהל', staff: 'צוות', player: 'שחקן' };
const ROLE_TAG = { owner: 'gold', admin: 'blue', staff: 'green', player: 'gray' };
const PERM_LABEL = {
  manage_users: 'חסימת משתמשים',
  manage_shop: 'חנות',
  manage_codes: 'קודי מימוש',
  manage_content: 'חדשות, קהילה והורדות',
  manage_servers: 'שרתים',
  manage_tournaments: 'טורנירים',
  manage_stats: 'סטטיסטיקות',
  view_audit: 'יומן פעולות'
};
const PERM_ORDER = Object.keys(PERM_LABEL);

const ICONS = {
  home: '<path d="M3 11l9-8 9 8"/><path d="M5 10v10h14V10"/><path d="M10 20v-6h4v6"/>',
  library: '<rect x="3" y="4" width="7" height="16" rx="1.5"/><rect x="14" y="4" width="7" height="16" rx="1.5"/>',
  servers: '<rect x="3" y="4" width="18" height="6" rx="2"/><rect x="3" y="14" width="18" height="6" rx="2"/><path d="M7 7h.01M7 17h.01"/>',
  board: '<path d="M5 20V10M12 20V4M19 20v-7"/>',
  trophy: '<path d="M8 4h8v5a4 4 0 01-8 0V4z"/><path d="M8 6H4v1a4 4 0 004 4M16 6h4v1a4 4 0 01-4 4"/><path d="M12 13v4M8 20h8M10 17h4"/>',
  heart: '<path d="M12 20s-7-4.4-9-9.2C1.8 7.6 3.6 5 6.5 5c1.8 0 3.2 1 3.8 2.2h3.4C14.3 6 15.7 5 17.5 5 20.4 5 22.2 7.6 21 10.8 19 15.6 12 20 12 20z"/>',
  download: '<path d="M12 4v11M7 11l5 5 5-5"/><path d="M4 20h16"/>',
  gear: '<circle cx="12" cy="12" r="3"/><path d="M12 2v3M12 19v3M2 12h3M19 12h3M4.9 4.9l2.1 2.1M17 17l2.1 2.1M4.9 19.1L7 17M17 7l2.1-2.1"/>',
  shield: '<path d="M12 3l8 3v6c0 5-3.5 8-8 9-4.5-1-8-4-8-9V6l8-3z"/><path d="M9 12l2 2 4-4"/>',
  play: '<path d="M7 4l13 8-13 8z" fill="currentColor" stroke="none"/>',
  search: '<circle cx="11" cy="11" r="7"/><path d="M20 20l-4-4"/>',
  list: '<path d="M4 6h16M4 12h16M4 18h16"/>',
  grid: '<rect x="4" y="4" width="7" height="7" rx="1"/><rect x="13" y="4" width="7" height="7" rx="1"/><rect x="4" y="13" width="7" height="7" rx="1"/><rect x="13" y="13" width="7" height="7" rx="1"/>',
  plus: '<path d="M12 5v14M5 12h14"/>',
  trash: '<path d="M4 7h16M9 7V4h6v3M6 7l1 13h10l1-13"/>',
  close: '<path d="M5 5l14 14M19 5L5 19"/>',
  minus: '<path d="M5 12h14"/>',
  check: '<circle cx="12" cy="12" r="9"/><path d="M8 12l3 3 5-6"/>',
  logout: '<path d="M10 4H5v16h5"/><path d="M15 8l4 4-4 4M19 12H9"/>',
  youtube: '<rect x="3" y="6" width="18" height="12" rx="4"/><path d="M10 9.5v5l4.5-2.5z" fill="currentColor" stroke="none"/>',
  tiktok: '<path d="M14 4v10.5a3.5 3.5 0 11-3.5-3.5"/><path d="M14 4c.4 2.4 2 4 4.5 4.2"/>',
  discord: '<path d="M7 7c3-1.4 7-1.4 10 0 1.8 2.6 2.7 5.4 2.6 8.6-1.5 1.2-3 1.8-4.5 2.2l-.9-1.5c.6-.2 1.1-.5 1.6-.9-3.2 1.4-6.9 1.4-10.1 0 .5.4 1 .7 1.6.9L6.4 18c-1.5-.4-3-1-4.5-2.2C1.8 12.400 2.700 9.600 4.500 7" transform="translate(.5 .5)"/><circle cx="9" cy="12.500" r="1.100" fill="currentColor"/><circle cx="15" cy="12.500" r="1.100" fill="currentColor"/>',
  link: '<path d="M10 14a4 4 0 005.7 0l3-3a4 4 0 00-5.700-5.700l-1 1"/><path d="M14 10a4 4 0 00-5.700 0l-3 3A4 4 0 0011 18.700l1-1"/>',
  edit: '<path d="M4 20h4L19 9l-4-4L4 16v4z"/>'
};

const state = {
  token: safeGet('token'),
  me: null,
  page: 'home',
  online: 0,
  adminTab: 'users'
};

function safeGet(k) {
  try { return localStorage.getItem(k); } catch (e) { return null; }
}
function safeSet(k, v) {
  try {
    if (v == null) localStorage.removeItem(k);
    else localStorage.setItem(k, v);
  } catch (e) { /* optional */ }
}

/* ---------- tiny DOM helper ---------- */

function h(tag, props, ...kids) {
  const el = document.createElement(tag);
  if (props) {
    for (const [k, v] of Object.entries(props)) {
      if (v == null || v === false) continue;
      if (k === 'class') el.className = v;
      else if (k === 'on') for (const [ev, fn] of Object.entries(v)) el.addEventListener(ev, fn);
      else if (k === 'text') el.textContent = v;
      else if (k in el) el[k] = v;
      else el.setAttribute(k, v === true ? '' : v);
    }
  }
  for (const kid of kids.flat(Infinity)) {
    if (kid == null || kid === false) continue;
    el.append(kid.nodeType ? kid : document.createTextNode(String(kid)));
  }
  return el;
}

function icon(name) {
  const s = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
  s.setAttribute('viewBox', '0 0 24 24');
  s.setAttribute('fill', 'none');
  s.setAttribute('stroke', 'currentColor');
  s.setAttribute('stroke-width', '1.8');
  s.setAttribute('stroke-linecap', 'round');
  s.setAttribute('stroke-linejoin', 'round');
  s.setAttribute('aria-hidden', 'true');
  s.innerHTML = ICONS[name] || '';
  return s;
}

function ibox(name, color) {
  return h('div', { class: 'ibox ' + color }, icon(name));
}

let toastTimer = null;
function toast(msg, bad) {
  const old = document.querySelector('.toast');
  if (old) old.remove();
  const t = h('div', { class: 'toast' + (bad ? ' bad' : ''), role: 'status' }, msg);
  document.body.append(t);
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => t.remove(), 3200);
}

/* ---------- server access ---------- */

async function api(method, path, body) {
  const r = await L.api({ method, path, body, token: state.token });
  if (r.status === 401 && state.token) {
    state.token = null;
    safeSet('token', null);
    showAuth();
  }
  return r;
}
const errText = (r, fallback) => (r.data && r.data.error) || fallback || 'משהו השתבש.';
const can = (perm) => Boolean(state.me && state.me.permissions.includes(perm));
const isAdmin = () => Boolean(state.me && (state.me.role === 'owner' || state.me.role === 'admin'));

/* ---------- modal + form helpers ---------- */

function openModal(title, content) {
  const bg = h('div', { class: 'modal-bg' });
  const box = h('div', { class: 'modal', role: 'dialog', 'aria-modal': 'true', 'aria-label': title }, h('h3', null, title), content);
  bg.append(box);
  const close = () => { bg.remove(); document.removeEventListener('keydown', onKey); };
  const onKey = (e) => { if (e.key === 'Escape') close(); };
  bg.addEventListener('mousedown', (e) => { if (e.target === bg) close(); });
  document.addEventListener('keydown', onKey);
  document.body.append(bg);
  const first = box.querySelector('input, textarea, select, button');
  if (first) first.focus();
  return close;
}

function pad(n) { return String(n).padStart(2, '0'); }
function toLocalInput(iso) {
  const d = new Date(iso);
  if (Number.isNaN(d.getTime())) return '';
  return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}T${pad(d.getHours())}:${pad(d.getMinutes())}`;
}

function formModal({ title, fields, values = {}, submitText = 'שמירה', onSave }) {
  const inputs = {};
  const err = h('p', { class: 'err', role: 'alert' });
  const form = h('form', { noValidate: true });
  for (const f of fields) {
    const v = values[f.key];
    let input;
    let extra = null;
    if (f.type === 'textarea' || f.type === 'lines') {
      input = h('textarea', { rows: f.rows || 3, placeholder: f.placeholder || '' });
      input.value = f.type === 'lines' ? (Array.isArray(v) ? v.join('\n') : '') : (v == null ? '' : v);
    } else if (f.type === 'checkbox') {
      input = h('input', { type: 'checkbox' });
      input.checked = Boolean(v);
    } else if (f.type === 'select') {
      input = h('select', null, f.options.map(([val, label]) => h('option', { value: val }, label)));
      input.value = v == null ? f.options[0][0] : v;
    } else if (f.type === 'datetime') {
      input = h('input', { type: 'datetime-local' });
      input.value = v ? toLocalInput(v) : '';
    } else if (f.type === 'number') {
      input = h('input', { type: 'number', step: f.step || '1' });
      input.value = v == null ? '' : v;
    } else if (f.type === 'file') {
      input = h('input', { type: 'text', placeholder: f.placeholder || '', dir: 'ltr' });
      input.value = v == null ? '' : v;
      extra = h('button', {
        type: 'button', class: 'btn sm',
        on: { click: async () => { const p = await L.pickFile(); if (p) input.value = p; } }
      }, 'בחירת קובץ');
    } else {
      input = h('input', { type: f.type || 'text', placeholder: f.placeholder || '', maxLength: f.max || 200 });
      if (f.dir) input.dir = f.dir;
      input.value = v == null ? '' : v;
    }
    inputs[f.key] = input;
    const body = extra ? h('div', { class: 'file-row' }, input, extra) : input;
    form.append(h('label', { class: 'field' + (f.type === 'checkbox' ? ' check' : '') },
      f.type === 'checkbox' ? [input, h('span', null, f.label)] : [h('span', null, f.label), body],
      f.hint ? h('small', { class: 'hint' }, f.hint) : null));
  }
  let close = () => {};
  const submit = h('button', { type: 'submit', class: 'btn primary' }, submitText);
  const cancel = h('button', { type: 'button', class: 'btn', on: { click: () => close() } }, 'ביטול');
  form.append(err, h('div', { class: 'actions' }, submit, cancel));
  form.addEventListener('submit', async (e) => {
    e.preventDefault();
    const out = {};
    for (const f of fields) {
      const el = inputs[f.key];
      switch (f.type) {
        case 'checkbox': out[f.key] = el.checked; break;
        case 'number': out[f.key] = el.value === '' ? (f.nullable ? null : 0) : Number(el.value); break;
        case 'lines': out[f.key] = el.value.split('\n').map((s) => s.trim()).filter(Boolean); break;
        case 'datetime': out[f.key] = el.value ? new Date(el.value).toISOString() : ''; break;
        case 'textarea': out[f.key] = el.value.trim(); break;
        default: out[f.key] = el.value.trim();
      }
    }
    submit.disabled = true;
    const res = await onSave(out);
    submit.disabled = false;
    if (res && res.ok === false) { err.textContent = res.error || 'משהו השתבש.'; return; }
    close();
  });
  close = openModal(title, form);
  return close;
}

function confirmModal(text, onYes) {
  let close = () => {};
  const yes = h('button', { class: 'btn danger', on: { click: async () => { close(); await onYes(); } } }, 'כן, למחוק');
  const no = h('button', { class: 'btn', on: { click: () => close() } }, 'ביטול');
  close = openModal('אישור', h('div', null, h('p', null, text), h('div', { class: 'actions' }, yes, no)));
}

/* ---------- shell ---------- */

const NAV = [
  ['home', 'בית', 'home'],
  ['library', 'ספרייה', 'library'],
  ['servers', 'שרתים', 'servers'],
  ['board', 'דירוג', 'board'],
  ['tournaments', 'טורנירים', 'trophy'],
  ['donate', 'תרומות', 'heart']
];

function greeting() {
  const hr = new Date().getHours();
  if (hr >= 5 && hr < 12) return 'בוקר טוב';
  if (hr >= 12 && hr < 17) return 'צהריים טובים';
  if (hr >= 17 && hr < 21) return 'ערב טוב';
  return 'לילה טוב';
}

function winCtl() {
  return h('div', null,
    h('div', { class: 'drag' }),
    h('div', { class: 'win-ctl' },
      h('button', { type: 'button', 'aria-label': 'מזעור', on: { click: () => L.minimize() } }, icon('minus')),
      h('button', { type: 'button', 'aria-label': 'סגירה', on: { click: () => L.close() } }, icon('close'))));
}

function avatar(name, cls) {
  return h('div', { class: 'avatar ' + (cls || ''), 'aria-hidden': 'true' }, (name || '?').slice(0, 1).toUpperCase());
}

let navButtons = {};
function buildShell() {
  const app = document.getElementById('app');
  app.textContent = '';
  navButtons = {};
  const mk = (id, label, ic) => {
    const b = h('button', { class: 'nav', type: 'button', 'aria-label': label, on: { click: () => go(id) } }, icon(ic), h('span', null, label));
    navButtons[id] = b;
    return b;
  };
  const side = h('nav', { class: 'side', 'aria-label': 'ניווט' },
    h('img', { class: 'logo', src: 'logo.jpg', alt: 'OGIL Reborn' }),
    h('div', { class: 'logo-t' }, 'OGIL REBORN'),
    h('div', { class: 'sep' }),
    NAV.map(([id, label, ic]) => mk(id, label, ic)),
    h('div', { class: 'grow' }),
    h('div', { class: 'sep' }),
    state.me.permissions.length ? mk('admin', 'ניהול', 'shield') : null,
    mk('downloads', 'הורדות', 'download'),
    mk('settings', 'הגדרות', 'gear'),
    avatar(state.me.username));
  app.append(h('div', { class: 'stars' }), winCtl(), h('main', { class: 'main', id: 'view' }), side);
}

let renderSeq = 0;
async function go(page) {
  state.page = page;
  for (const [id, b] of Object.entries(navButtons)) b.classList.toggle('on', id === page);
  const view = document.getElementById('view');
  const seq = ++renderSeq;
  view.textContent = '';
  view.append(h('div', { class: 'empty' }, 'טוען...'));
  let el;
  try {
    el = await PAGES[page]();
  } catch (e) {
    el = h('div', { class: 'empty' }, 'משהו השתבש בטעינת הדף.');
    console.error(e);
  }
  if (seq !== renderSeq) return;
  view.textContent = '';
  view.append(el);
  view.scrollTop = 0;
}

function pageHeader(title, sub, tools) {
  return h('div', { class: 'ph' },
    h('div', null, h('h1', null, title), sub ? h('p', null, sub) : null),
    tools ? h('div', { class: 'tools' }, tools) : null);
}

/* ---------- home ---------- */

function openUrl(url) {
  if (url) L.openExternal(url);
  else toast('עדיין לא הוגדר קישור.', true);
}

function commCard(c) {
  const map = { youtube: ['youtube', 'red'], tiktok: ['tiktok', 'pink'], discord: ['discord', 'blurple'], instagram: ['link', 'pink'], other: ['link', 'blue'] };
  const [ic, color] = map[c.kind] || map.other;
  return h('button', { class: 'comm', type: 'button', on: { click: () => openUrl(c.url) } },
    ibox(ic, color),
    h('div', { class: 'comm-t' }, h('b', null, c.name), h('span', { dir: 'ltr' }, c.handle || 'לא הוגדר')));
}

async function playNow() {
  const lib = await L.libraryList();
  if (!lib.length) {
    toast('הוסף קודם את הפרויקט שלך בספרייה.');
    await go('library');
    openAddProject();
    return;
  }
  const last = safeGet('lastPlayed');
  await launchProject(lib.find((p) => p.id === last) || lib[0]);
}

async function launchProject(p) {
  const r = await L.libraryLaunch(p.id);
  if (r.ok) { safeSet('lastPlayed', p.id); toast('מפעיל את ' + p.name + '...'); }
  else toast(r.error || 'לא הצלחתי להפעיל.', true);
}

async function pageHome() {
  const r = await api('GET', '/api/overview');
  const ov = r.ok ? r.data : { news: {}, community: [], online: 0 };
  const n = ov.news || {};
  const comm = ov.community || [];
  state.online = ov.online;
  const cards = [];
  const disc = comm.find((c) => c.kind === 'discord');
  if (disc) cards.push(commCard(disc));
  cards.push(h('button', { class: 'comm', type: 'button', on: { click: () => go('donate') } },
    ibox('heart', 'red'),
    h('div', { class: 'comm-t' }, h('b', null, 'תרומות'), h('span', null, 'תרמו לפרויקט וקבלו הטבות שוות!'))));
  for (const c of comm) if (c !== disc) cards.push(commCard(c));
  return h('div', { class: 'page' },
    h('div', { class: 'home-top' },
      h('div', { class: 'greet' },
        h('h1', null, greeting() + ', ', h('span', { class: 'accent' }, state.me.username)),
        h('p', null, 'ברוכים הבאים חזרה ל-OGIL Reborn')),
      h('div', { class: 'pill' }, h('span', { class: 'dot' }), `${ov.online} שחקנים מחוברים`)),
    h('section', { class: 'hero', 'aria-label': 'חדשות' },
      h('div', { class: 'hero-body' },
        n.badge ? h('span', { class: 'badge' }, n.badge) : null,
        // The key art already carries the project name, so skip a duplicate title.
        n.title && n.title.trim().toLowerCase() !== 'ogil reborn' ? h('h2', null, n.title) : null,
        n.subtitle ? h('h3', null, n.subtitle) : null,
        n.body ? h('p', null, n.body) : null),
      h('button', { class: 'btn primary big', type: 'button', on: { click: playNow } }, n.buttonText || 'שחק עכשיו', icon('play'))),
    h('h2', { class: 'sec-title' }, 'הקהילה'),
    h('div', { class: 'comm-row' }, cards));
}

/* ---------- library ---------- */

function openAddProject() {
  formModal({
    title: 'הוספת פרויקט',
    submitText: 'הוספה',
    values: { type: 'exe' },
    fields: [
      { key: 'name', label: 'שם הפרויקט', max: 60 },
      { key: 'version', label: 'גרסה (לא חובה)', max: 20, dir: 'ltr' },
      { key: 'type', label: 'סוג', type: 'select', options: [['exe', 'קובץ משחק במחשב'], ['web', 'קישור לדפדפן']] },
      { key: 'target', label: 'קובץ או קישור', type: 'file', placeholder: 'C:\\Games\\OGIL\\OGIL.exe או https://...', hint: 'בקובץ משחק בחר את ה-exe. בקישור כתוב כתובת שמתחילה ב-https.' },
      { key: 'args', label: 'פרמטרים להפעלה (לא חובה)', max: 200, dir: 'ltr' }
    ],
    onSave: async (v) => {
      const r = await L.libraryAdd(v);
      if (r.ok) { toast('הפרויקט נוסף.'); go('library'); }
      return r;
    }
  });
}

async function pageLibrary() {
  const lib = await L.libraryList();
  const view = safeGet('libView') === 'list' ? 'list' : 'grid';
  const setView = (v) => { safeSet('libView', v); go('library'); };
  const remove = (p) => confirmModal(`להסיר את "${p.name}" מהספרייה? הקבצים עצמם לא יימחקו.`, async () => { await L.libraryRemove(p.id); go('library'); });
  const sub = (p) => `גרסה ${p.version || '—'} · ${p.type === 'web' ? 'דפדפן' : 'קובץ משחק'}`;
  const body = !lib.length
    ? h('div', { class: 'empty' }, 'עדיין אין פרויקטים בספרייה. לחץ על "הוספת פרויקט" כדי לחבר את המשחק שלך.')
    : view === 'grid'
      ? h('div', { class: 'proj-grid' }, lib.map((p) => h('article', { class: 'card proj' },
        h('div', { class: 'art' }, h('button', { class: 'rm', type: 'button', 'aria-label': 'הסרה', on: { click: () => remove(p) } }, icon('trash'))),
        h('div', { class: 'meta' }, h('b', null, p.name), h('span', null, sub(p)),
          h('button', { class: 'btn primary', type: 'button', on: { click: () => launchProject(p) } }, p.type === 'web' ? 'פתח' : 'הפעל משחק', icon('play'))))))
      : h('div', { class: 'proj-list' }, lib.map((p) => h('div', { class: 'row' },
        h('div', { class: 'thumb' }),
        h('div', { class: 'info' }, h('b', null, p.name), h('span', null, sub(p))),
        h('button', { class: 'btn sm danger', type: 'button', on: { click: () => remove(p) } }, 'הסרה'),
        h('button', { class: 'btn primary', type: 'button', on: { click: () => launchProject(p) } }, p.type === 'web' ? 'פתח' : 'הפעל משחק', icon('play')))));
  return h('div', { class: 'page' },
    pageHeader('ספריית משחקים', 'הפרויקטים שלך. הוסף משחק או קישור והפעל אותו מכאן.', [
      h('button', { class: 'btn primary', type: 'button', on: { click: openAddProject } }, icon('plus'), 'הוספת פרויקט'),
      h('button', { class: 'btn icon-btn' + (view === 'list' ? ' on' : ''), type: 'button', 'aria-label': 'תצוגת רשימה', on: { click: () => setView('list') } }, icon('list')),
      h('button', { class: 'btn icon-btn' + (view === 'grid' ? ' on' : ''), type: 'button', 'aria-label': 'תצוגת כרטיסים', on: { click: () => setView('grid') } }, icon('grid'))
    ]),
    body);
}

/* ---------- servers ---------- */

async function pageServers() {
  const r = await api('GET', '/api/servers');
  const items = r.ok ? r.data.items : [];
  const players = items.reduce((s, x) => s + x.players, 0);
  let filter = '';
  const list = h('div', { class: 'list' });
  const chips = h('div', { class: 'filters' });
  const playlists = Array.from(new Set(items.map((s) => s.playlist).filter(Boolean)));
  const draw = () => {
    list.textContent = '';
    chips.textContent = '';
    if (playlists.length) {
      const mkChip = (val, label) => h('button', { type: 'button', class: 'chip' + (filter === val ? ' on' : ''), on: { click: () => { filter = val; draw(); } } }, label);
      chips.append(h('span', { class: 'muted' }, 'פלייליסט:'), mkChip('', 'הכל'), playlists.map((p) => mkChip(p, p)));
    }
    const shown = items.filter((s) => !filter || s.playlist === filter);
    if (!shown.length) list.append(h('div', { class: 'empty' }, 'אין כרגע שרתים פעילים.'));
    for (const s of shown) {
      const full = s.players >= s.capacity;
      const bar = h('i');
      bar.style.width = Math.round((s.players / s.capacity) * 100) + '%';
      list.append(h('div', { class: 'srv' },
        h('div', { class: 'l' },
          h('b', null, s.name),
          s.playlist ? h('span', { dir: 'ltr' }, s.playlist) : null,
          h('span', { class: 'tag ' + (full || !s.joinable ? 'red' : '') }, full ? 'מלא' : s.joinable ? 'ניתן להצטרף' : 'סגור')),
        h('div', { class: 'r' }, h('span', { class: 'count' }, `${s.players}/${s.capacity}`), h('div', { class: 'bar' }, bar))));
    }
  };
  draw();
  return h('div', { class: 'page' },
    pageHeader('מצב שרתים', 'נתונים חיים על השרתים של הפרויקט.', h('div', { class: 'chips' },
      h('div', { class: 'stat blue' }, h('b', null, players), h('span', null, 'שחקנים מחוברים')),
      h('div', { class: 'stat' }, h('b', null, items.length), h('span', null, 'שרתים פעילים')))),
    chips, list);
}

/* ---------- leaderboard ---------- */

async function pageBoard() {
  const r = await api('GET', '/api/leaderboard?sort=points');
  const all = r.ok ? r.data.players : [];
  const total = r.ok ? r.data.total : 0;
  let sort = 'points';
  let q = '';
  const list = h('div', { class: 'list' });
  const shownLine = h('p', { class: 'muted' });
  const sortBar = h('div', { class: 'filters' });
  const draw = () => {
    sortBar.textContent = '';
    for (const [k, label] of [['points', 'נקודות'], ['wins', 'ניצחונות'], ['losses', 'הפסדים']]) {
      sortBar.append(h('button', { type: 'button', class: 'chip' + (sort === k ? ' on' : ''), on: { click: () => { sort = k; draw(); } } }, label));
    }
    const rows = all.slice().sort((a, b) => b[sort] - a[sort] || a.username.localeCompare(b.username))
      .filter((p) => !q || p.username.toLowerCase().includes(q));
    shownLine.textContent = `מציג ${rows.length} מתוך ${total} שחקנים`;
    list.textContent = '';
    if (!rows.length) list.append(h('div', { class: 'empty' }, 'אין שחקנים להצגה.'));
    rows.forEach((p, i) => {
      list.append(h('div', { class: 'lb' + (!q && i < 3 ? ' top' + (i + 1) : '') },
        h('div', { class: 'rank' }, '#' + (i + 1)),
        avatar(p.username, 'av'),
        h('div', { class: 'nm' }, p.username),
        h('div', { class: 'nums' },
          h('div', { class: 'l' }, h('b', null, p.losses.toLocaleString('en-US')), h('span', null, 'הפסדים')),
          h('div', { class: 'w' }, h('b', null, p.wins.toLocaleString('en-US')), h('span', null, 'ניצחונות')),
          h('div', { class: 'p' }, h('b', null, p.points.toLocaleString('en-US')), h('span', null, 'נקודות')))));
    });
  };
  const input = h('input', { type: 'text', placeholder: 'חפש לפי שם משתמש...', 'aria-label': 'חיפוש', on: { input: (e) => { q = e.target.value.trim().toLowerCase(); draw(); } } });
  draw();
  return h('div', { class: 'page' },
    pageHeader('טבלת דירוג', 'צפה בשחקנים המובילים בפרויקט.'),
    h('div', { class: 'filters' }, h('div', { class: 'search' }, icon('search'), input), h('span', { class: 'muted' }, 'מיין לפי:'), sortBar),
    shownLine, list);
}

/* ---------- tournaments ---------- */

const fmtDate = (iso) => new Date(iso).toLocaleString('he-IL', { dateStyle: 'medium', timeStyle: 'short' });

async function pageTournaments() {
  const r = await api('GET', '/api/tournaments');
  const items = r.ok ? r.data.items : [];
  const active = items.filter((t) => t.state !== 'ended').sort((a, b) => Date.parse(a.startsAt) - Date.parse(b.startsAt));
  const past = items.filter((t) => t.state === 'ended').sort((a, b) => Date.parse(b.startsAt) - Date.parse(a.startsAt));
  let tab = 'active';
  const list = h('div', { class: 'list' });
  const tabs = h('div', { class: 'tabs', role: 'tablist' });
  const draw = () => {
    tabs.textContent = '';
    tabs.append(
      h('button', { type: 'button', class: tab === 'active' ? 'on' : '', on: { click: () => { tab = 'active'; draw(); } } }, `פעילים וקרובים (${active.length})`),
      h('button', { type: 'button', class: tab === 'past' ? 'on' : '', on: { click: () => { tab = 'past'; draw(); } } }, `שהיו (${past.length})`));
    list.textContent = '';
    const rows = tab === 'active' ? active : past;
    if (!rows.length) list.append(h('div', { class: 'empty' }, tab === 'active' ? 'אין כרגע טורנירים פעילים או קרובים.' : 'עדיין לא היו טורנירים.'));
    for (const t of rows) {
      list.append(h('div', { class: 'tour' },
        h('div', null, h('b', null, t.name), h('div', { class: 'sub' }, fmtDate(t.startsAt) + (t.desc ? ' · ' + t.desc : ''))),
        h('div', null,
          t.prize ? h('span', { class: 'tag gold' }, 'פרס: ' + t.prize) : null, ' ',
          h('span', { class: 'tag ' + (t.state === 'live' ? '' : t.state === 'upcoming' ? 'blue' : 'gray') }, t.state === 'live' ? 'משחקים עכשיו' : t.state === 'upcoming' ? 'בקרוב' : 'הסתיים'))));
    }
  };
  draw();
  return h('div', { class: 'page' }, pageHeader('טורנירים', 'הטורנירים הקרובים, הפעילים וההיסטוריה.'), tabs, list);
}

/* ---------- donations / shop ---------- */

function openRedeem() {
  formModal({
    title: 'מימוש קוד',
    submitText: 'מימוש',
    fields: [{ key: 'code', label: 'הדבק את הקוד שקיבלת', placeholder: 'XXXX-XXXX-XXXX', dir: 'ltr', max: 40 }],
    onSave: async (v) => {
      const r = await api('POST', '/api/redeem', { code: v.code });
      if (!r.ok) return { ok: false, error: errText(r, 'המימוש נכשל.') };
      state.me = r.data.me;
      toast('הקוד מומש בהצלחה!');
      go('donate');
      return { ok: true };
    }
  });
}

async function pageDonate() {
  const r = await api('GET', '/api/shop');
  const items = r.ok ? r.data.items : [];
  const mine = items.filter((i) => state.me.items.includes(i.id));
  const comm = await api('GET', '/api/community');
  const disc = comm.ok ? comm.data.items.find((c) => c.kind === 'discord') : null;
  return h('div', { class: 'page' },
    h('div', { class: 'ph' },
      h('div', null, h('h1', null, 'תמיכה ב-OGIL Reborn'), h('p', null, 'בוחרים חבילה, מקבלים קוד Redeem ומנהלים את ההטבות ישירות מתוך הלאנצ\'ר.')),
      h('span', { class: 'tag blue' }, 'DONATIONS')),
    h('div', { class: 'card' },
      h('div', { class: 'profile' },
        h('div', { class: 'who' }, ibox('shield', 'blue'), h('div', null, h('b', null, 'מצב התרומה שלך'),
          h('div', { class: 'muted' }, mine.length ? 'הטבות פעילות: ' + mine.map((i) => i.name).join(', ') : 'אין עדיין הטבות פעילות.'))),
        h('div', { class: 'filters' },
          h('button', { class: 'btn gold', type: 'button', on: { click: openRedeem } }, 'מימוש קוד'),
          h('button', { class: 'btn', type: 'button', on: { click: () => openUrl(disc && disc.url) } }, 'תמיכה בדיסקורד')))),
    h('h2', { class: 'sec-title' }, 'חבילות התמיכה'),
    items.length ? h('div', { class: 'packs' }, items.map((i) => h('div', { class: 'pack' + (i.highlight ? ' hl' : '') },
      h('div', { class: 'top' },
        h('div', null, h('h3', null, i.name), i.tag ? h('span', { class: 'tag ' + (i.highlight ? 'gold' : 'blue') }, i.tag) : null),
        h('div', { class: 'price' }, '₪' + i.price, i.oldPrice ? h('s', null, '₪' + i.oldPrice) : null)),
      i.desc ? h('p', { class: 'muted' }, i.desc) : null,
      h('ul', null, i.features.map((f) => h('li', null, icon('check'), f))),
      state.me.items.includes(i.id) ? h('span', { class: 'tag' }, 'כבר אצלך') : null)))
      : h('div', { class: 'empty' }, 'עדיין אין חבילות בחנות.'),
    h('div', { class: 'card steps' }, h('b', null, 'איך זה עובד'),
      h('ol', null,
        h('li', null, 'בחר חבילה ופנה אלינו בדיסקורד.'),
        h('li', null, 'שלם, וקבל קוד Redeem מהצוות.'),
        h('li', null, 'לחץ כאן על "מימוש קוד" והדבק אותו. ההטבה תופיע מיד.'))));
}

/* ---------- downloads ---------- */

async function pageDownloads() {
  const r = await api('GET', '/api/builds');
  const items = r.ok ? r.data.items : [];
  return h('div', { class: 'page' },
    pageHeader('הורדות', 'גרסאות להורדה של הפרויקט.'),
    items.length ? h('div', { class: 'list' }, items.map((b) => h('div', { class: 'tour' },
      h('div', null, h('b', null, b.name), h('div', { class: 'sub' }, b.version ? 'גרסה ' + b.version : '')),
      h('button', { class: 'btn primary', type: 'button', on: { click: () => openUrl(b.url) } }, icon('download'), 'הורדה'))))
      : h('div', { class: 'empty' }, 'עדיין לא הועלו גרסאות להורדה.'));
}

/* ---------- settings ---------- */

async function pageSettings() {
  const s = await L.getSettings();
  const urlIn = h('input', { type: 'text', dir: 'ltr', value: s.serverUrl });
  const argsIn = h('input', { type: 'text', dir: 'ltr', value: s.defaultArgs || '', placeholder: '-windowed' });
  const err = h('p', { class: 'err' });
  const saveBtn = h('button', {
    class: 'btn primary', type: 'button',
    on: {
      click: async () => {
        const r = await L.saveSettings({ serverUrl: urlIn.value, defaultArgs: argsIn.value });
        if (!r.ok) { err.textContent = r.error; return; }
        err.textContent = '';
        toast('ההגדרות נשמרו.');
      }
    }
  }, 'שמירה');
  return h('div', { class: 'page' },
    pageHeader('הגדרות'),
    h('div', { class: 'card profile' },
      h('div', { class: 'who' }, avatar(state.me.username),
        h('div', null, h('b', null, state.me.username), h('div', null, h('span', { class: 'tag ' + ROLE_TAG[state.me.role] }, ROLE_LABEL[state.me.role])))),
      h('button', {
        class: 'btn danger', type: 'button',
        on: { click: async () => { await api('POST', '/api/logout'); state.token = null; safeSet('token', null); showAuth(); } }
      }, icon('logout'), 'התנתקות')),
    h('div', { class: 'two' },
      h('div', { class: 'card' },
        h('h3', null, 'חיבור לשרת'),
        h('label', { class: 'field' }, h('span', null, 'כתובת השרת'), urlIn,
          h('small', { class: 'hint' }, 'אחרי שינוי הכתובת צריך להתחבר מחדש.')),
        err, saveBtn),
      h('div', { class: 'card' },
        h('h3', null, 'הפעלת משחק'),
        h('label', { class: 'field' }, h('span', null, 'פרמטרים לכל הפרויקטים'), argsIn,
          h('small', { class: 'hint' }, 'מתווספים בהפעלה של כל קובץ משחק. אפשר להוסיף גם פרמטרים לכל פרויקט בנפרד.')),
        h('button', { class: 'btn primary', type: 'button', on: { click: () => saveBtn.click() } }, 'שמירה'))));
}

/* ---------- admin ---------- */

function crudSection({ title, col, perm, fields, row, defaults = {} }) {
  const wrap = h('section', { class: 'card admin-sec' });
  const draw = async () => {
    const r = await api('GET', '/api/' + col);
    const items = r.ok ? r.data.items : [];
    wrap.textContent = '';
    const editable = can(perm);
    wrap.append(h('div', { class: 'head' }, h('h3', null, title),
      editable ? h('button', {
        class: 'btn sm primary', type: 'button',
        on: { click: () => formModal({ title: 'הוספה: ' + title, fields, values: defaults, onSave: async (v) => { const x = await api('POST', '/api/admin/' + col, v); if (!x.ok) return { ok: false, error: errText(x) }; draw(); return { ok: true }; } }) }
      }, icon('plus'), 'הוספה') : null));
    if (!items.length) wrap.append(h('div', { class: 'empty' }, 'עדיין ריק.'));
    for (const it of items) {
      const [t, sub] = row(it);
      wrap.append(h('div', { class: 'arow' },
        h('div', { class: 't' }, h('b', null, t), sub ? h('span', null, sub) : null),
        editable ? h('div', { class: 'b' },
          h('button', {
            class: 'btn sm', type: 'button',
            on: { click: () => formModal({ title: 'עריכה: ' + t, fields, values: it, onSave: async (v) => { const x = await api('PUT', `/api/admin/${col}/${it.id}`, v); if (!x.ok) return { ok: false, error: errText(x) }; draw(); return { ok: true }; } }) }
          }, 'עריכה'),
          h('button', {
            class: 'btn sm danger', type: 'button',
            on: { click: () => confirmModal(`למחוק את "${t}"?`, async () => { await api('DELETE', `/api/admin/${col}/${it.id}`); draw(); }) }
          }, 'מחיקה')) : null));
    }
  };
  draw();
  return wrap;
}

async function adminUsers() {
  const r = await api('GET', '/api/admin/users');
  if (!r.ok) return h('div', { class: 'empty' }, errText(r));
  const wrap = h('div', { class: 'card scroll-x' });
  const reload = () => go('admin');
  const rows = r.data.items.map((u) => {
    const isMe = u.id === state.me.id;
    const targetAdmin = u.role === 'owner' || u.role === 'admin';
    // Role: only the owner can appoint or remove admins.
    let roleCell;
    if (state.me.role === 'owner' && u.role !== 'owner' && !isMe) {
      const sel = h('select', { 'aria-label': 'תפקיד' }, [['player', 'שחקן / צוות'], ['admin', 'מנהל']].map(([v, l]) => h('option', { value: v }, l)));
      sel.value = u.role === 'admin' ? 'admin' : 'player';
      sel.addEventListener('change', async () => {
        const x = await api('POST', `/api/admin/users/${u.id}/role`, { role: sel.value });
        if (!x.ok) toast(errText(x), true);
        reload();
      });
      roleCell = [h('span', { class: 'tag ' + ROLE_TAG[u.role] }, ROLE_LABEL[u.role]), ' ', sel];
    } else roleCell = h('span', { class: 'tag ' + ROLE_TAG[u.role] }, ROLE_LABEL[u.role]);

    // Permissions: owner and admins can edit them for non-admins.
    let permCell;
    if (targetAdmin) permCell = h('span', { class: 'muted' }, 'כל ההרשאות');
    else {
      const boxes = PERM_ORDER.map((p) => {
        const cb = h('input', { type: 'checkbox', disabled: !state.me.canGrant });
        cb.checked = u.permissions.includes(p);
        const lab = h('label', { class: cb.checked ? 'on' : '' }, cb, PERM_LABEL[p]);
        cb.addEventListener('change', async () => {
          const next = PERM_ORDER.filter((x) => (x === p ? cb.checked : boxes.find((b) => b.p === x).cb.checked));
          const x = await api('POST', `/api/admin/users/${u.id}/permissions`, { permissions: next });
          if (!x.ok) { cb.checked = !cb.checked; toast(errText(x), true); return; }
          lab.classList.toggle('on', cb.checked);
        });
        return { p, cb, lab };
      });
      permCell = h('div', { class: 'perms' }, boxes.map((b) => b.lab));
    }

    const actions = [];
    if (can('manage_stats')) {
      actions.push(h('button', {
        class: 'btn sm', type: 'button',
        on: { click: () => formModal({ title: 'סטטיסטיקות: ' + u.username, values: u.stats, fields: [
          { key: 'points', label: 'נקודות', type: 'number' }, { key: 'wins', label: 'ניצחונות', type: 'number' }, { key: 'losses', label: 'הפסדים', type: 'number' }],
        onSave: async (v) => { const x = await api('POST', '/api/admin/stats', Object.assign({ username: u.username }, v)); if (!x.ok) return { ok: false, error: errText(x) }; toast('נשמר.'); reload(); return { ok: true }; } }) }
      }, 'סטטיסטיקות'));
    }
    const canBan = can('manage_users') && !isMe && u.role !== 'owner' && !(u.role === 'admin' && state.me.role !== 'owner');
    if (canBan) {
      actions.push(h('button', {
        class: 'btn sm danger', type: 'button',
        on: { click: async () => { const x = await api('POST', `/api/admin/users/${u.id}/ban`, { banned: !u.banned }); if (!x.ok) toast(errText(x), true); reload(); } }
      }, u.banned ? 'ביטול חסימה' : 'חסימה'));
    }
    return h('tr', null,
      h('td', null, h('b', null, u.username), u.banned ? [' ', h('span', { class: 'tag red' }, 'חסום')] : null),
      h('td', null, roleCell), h('td', null, permCell), h('td', null, h('div', { class: 'perms' }, actions)));
  });
  wrap.append(h('table', { class: 'table' },
    h('thead', null, h('tr', null, h('th', null, 'משתמש'), h('th', null, 'תפקיד'), h('th', null, 'הרשאות'), h('th', null, 'פעולות'))),
    h('tbody', null, rows)));
  return h('div', { class: 'page' },
    h('div', { class: 'card steps' }, h('b', null, 'איך ההרשאות עובדות'),
      h('ol', null,
        h('li', null, 'רק הבעלים יכול למנות מנהל או להסיר מנהל.'),
        h('li', null, 'מנהל ממונה יכול לתת ולהסיר הרשאות לצוות ולשחקנים, אבל לא יכול למנות מנהלים אחרים.'),
        h('li', null, 'חבר צוות מקבל רק את ההרשאות שסימנת לו, ולא יכול לתת הרשאות לאחרים.'))),
    wrap);
}

async function adminShop() {
  const shop = crudSection({
    title: 'חנות', col: 'shop', perm: 'manage_shop',
    defaults: { highlight: false },
    fields: [
      { key: 'name', label: 'שם', max: 40 }, { key: 'tag', label: 'תגית', max: 30 },
      { key: 'price', label: 'מחיר ב-₪', type: 'number', step: '0.01' },
      { key: 'oldPrice', label: 'מחיר קודם (לא חובה)', type: 'number', step: '0.01', nullable: true },
      { key: 'desc', label: 'תיאור', type: 'textarea', rows: 2 },
      { key: 'features', label: 'מה כלול (שורה לכל פריט)', type: 'lines', rows: 4 },
      { key: 'highlight', label: 'הדגשה בזהב', type: 'checkbox' }
    ],
    row: (i) => [`${i.name} · ₪${i.price}`, i.tag]
  });
  const codes = h('section', { class: 'card admin-sec' });
  if (can('manage_codes')) {
    const shopRes = await api('GET', '/api/shop');
    const items = shopRes.ok ? shopRes.data.items : [];
    const draw = async () => {
      const cr = await api('GET', '/api/admin/codes');
      const list = cr.ok ? cr.data.items : [];
      codes.textContent = '';
      codes.append(h('div', { class: 'head' }, h('h3', null, 'קודי מימוש'),
        h('button', {
          class: 'btn sm primary', type: 'button',
          on: { click: () => {
            if (!items.length) { toast('קודם הוסף פריט לחנות.', true); return; }
            formModal({ title: 'יצירת קודים', submitText: 'יצירה', values: { count: 1 }, fields: [
              { key: 'itemId', label: 'פריט', type: 'select', options: items.map((i) => [i.id, i.name]) },
              { key: 'count', label: 'כמות (עד 50)', type: 'number' }],
            onSave: async (v) => {
              const x = await api('POST', '/api/admin/codes', v);
              if (!x.ok) return { ok: false, error: errText(x) };
              const ta = h('textarea', { class: 'codes-box', readOnly: true });
              ta.value = x.data.codes.join('\n');
              openModal('הקודים שנוצרו', h('div', null, h('p', { class: 'muted' }, 'העתק ושלח לשחקן. כל קוד עובד פעם אחת.'), ta));
              draw();
              return { ok: true };
            } });
          } }
        }, icon('plus'), 'יצירת קודים')));
      if (!list.length) codes.append(h('div', { class: 'empty' }, 'עדיין לא נוצרו קודים.'));
      for (const c of list.slice(0, 30)) {
        const it = items.find((i) => i.id === c.itemId);
        codes.append(h('div', { class: 'arow' },
          h('div', { class: 't' }, h('b', { dir: 'ltr' }, c.code), h('span', null, (it ? it.name : 'פריט שנמחק') + ' · נוצר ע"י ' + c.createdBy)),
          c.usedBy ? h('span', { class: 'tag gray' }, 'מומש ע"י ' + c.usedBy) : h('span', { class: 'tag' }, 'פנוי')));
      }
    };
    await draw();
  }
  return h('div', { class: 'page' }, shop, can('manage_codes') ? codes : null);
}

async function adminContent() {
  const news = h('section', { class: 'card admin-sec' });
  const nr = await api('GET', '/api/overview');
  const cur = nr.ok ? nr.data.news : {};
  news.append(h('div', { class: 'head' }, h('h3', null, 'באנר הבית'),
    can('manage_content') ? h('button', {
      class: 'btn sm', type: 'button',
      on: { click: () => formModal({ title: 'עריכת באנר', values: cur, fields: [
        { key: 'badge', label: 'תגית קטנה', max: 40 }, { key: 'title', label: 'כותרת', max: 60 }, { key: 'subtitle', label: 'כותרת משנה', max: 100 },
        { key: 'body', label: 'טקסט', type: 'textarea', rows: 2 }, { key: 'buttonText', label: 'טקסט הכפתור', max: 30 }],
      onSave: async (v) => { const x = await api('PUT', '/api/admin/news', v); if (!x.ok) return { ok: false, error: errText(x) }; toast('נשמר.'); go('admin'); return { ok: true }; } }) }
    }, 'עריכה') : null),
  h('div', { class: 'arow' }, h('div', { class: 't' }, h('b', null, cur.title || ''), h('span', null, [cur.badge, cur.subtitle, cur.body].filter(Boolean).join(' · ')))));
  const community = crudSection({
    title: 'קהילה', col: 'community', perm: 'manage_content',
    defaults: { kind: 'discord' },
    fields: [
      { key: 'kind', label: 'סוג', type: 'select', options: [['discord', 'Discord'], ['youtube', 'YouTube'], ['tiktok', 'TikTok'], ['instagram', 'Instagram'], ['other', 'אחר']] },
      { key: 'name', label: 'שם', max: 30 }, { key: 'handle', label: 'שם משתמש להצגה', max: 40, dir: 'ltr' },
      { key: 'url', label: 'קישור', max: 500, dir: 'ltr', placeholder: 'https://...' }],
    row: (c) => [c.name, c.url || 'אין קישור']
  });
  const builds = crudSection({
    title: 'הורדות', col: 'builds', perm: 'manage_content',
    fields: [{ key: 'name', label: 'שם', max: 60 }, { key: 'version', label: 'גרסה', max: 20, dir: 'ltr' }, { key: 'url', label: 'קישור להורדה', max: 500, dir: 'ltr', placeholder: 'https://...' }],
    row: (b) => [b.name + (b.version ? ' · ' + b.version : ''), b.url]
  });
  return h('div', { class: 'page' }, news, community, builds);
}

async function adminPlay() {
  const servers = crudSection({
    title: 'שרתים', col: 'servers', perm: 'manage_servers',
    defaults: { joinable: true, players: 0, capacity: 35 },
    fields: [
      { key: 'name', label: 'שם', max: 60 }, { key: 'playlist', label: 'פלייליסט', max: 60, dir: 'ltr' },
      { key: 'players', label: 'שחקנים כרגע', type: 'number' }, { key: 'capacity', label: 'קיבולת', type: 'number' },
      { key: 'joinable', label: 'פתוח להצטרפות', type: 'checkbox' }],
    row: (s) => [s.name, `${s.players}/${s.capacity}` + (s.playlist ? ' · ' + s.playlist : '')]
  });
  const tours = crudSection({
    title: 'טורנירים', col: 'tournaments', perm: 'manage_tournaments',
    fields: [
      { key: 'name', label: 'שם', max: 60 }, { key: 'desc', label: 'תיאור', max: 200 }, { key: 'prize', label: 'פרס', max: 60 },
      { key: 'startsAt', label: 'התחלה', type: 'datetime' }, { key: 'endsAt', label: 'סיום (לא חובה)', type: 'datetime' }],
    row: (t) => [t.name, fmtDate(t.startsAt)]
  });
  return h('div', { class: 'page' }, servers, tours);
}

async function adminAudit() {
  const r = await api('GET', '/api/admin/audit');
  const items = r.ok ? r.data.items : [];
  return h('div', { class: 'page' }, h('section', { class: 'card admin-sec' }, h('h3', null, 'יומן פעולות'),
    items.length ? items.map((a) => h('div', { class: 'arow' }, h('div', { class: 't' }, h('b', null, `${a.by} · ${a.action}`), h('span', null, a.detail)), h('span', { class: 'muted' }, fmtDate(a.at))))
      : h('div', { class: 'empty' }, 'אין פעולות ביומן.')));
}

async function pageAdmin() {
  const tabs = [];
  if (isAdmin() || can('manage_users')) tabs.push(['users', 'משתמשים והרשאות', adminUsers]);
  if (can('manage_shop') || can('manage_codes')) tabs.push(['shop', 'חנות וקודים', adminShop]);
  if (can('manage_content')) tabs.push(['content', 'תוכן', adminContent]);
  if (can('manage_servers') || can('manage_tournaments')) tabs.push(['play', 'שרתים וטורנירים', adminPlay]);
  if (can('view_audit')) tabs.push(['audit', 'יומן', adminAudit]);
  if (!tabs.length) return h('div', { class: 'empty' }, 'אין לך הרשאות ניהול.');
  if (!tabs.find((t) => t[0] === state.adminTab)) state.adminTab = tabs[0][0];
  const current = tabs.find((t) => t[0] === state.adminTab);
  const body = await current[2]();
  const bar = h('div', { class: 'tabs', role: 'tablist' }, tabs.map(([id, label]) =>
    h('button', { type: 'button', class: id === state.adminTab ? 'on' : '', on: { click: () => { state.adminTab = id; go('admin'); } } }, label)));
  return h('div', { class: 'page' },
    pageHeader('ניהול', `מחובר בתור ${ROLE_LABEL[state.me.role]}.`), bar, body);
}

const PAGES = {
  home: pageHome, library: pageLibrary, servers: pageServers, board: pageBoard, tournaments: pageTournaments,
  donate: pageDonate, downloads: pageDownloads, settings: pageSettings, admin: pageAdmin
};

/* ---------- login / register ---------- */

async function showAuth() {
  const app = document.getElementById('app');
  app.textContent = '';
  const settings = await L.getSettings();
  let mode = 'login';
  const card = h('div', { class: 'auth' });
  const render = () => {
    card.textContent = '';
    const user = h('input', { type: 'text', maxLength: 20, autocomplete: 'username' });
    const pass = h('input', { type: 'password', autocomplete: mode === 'login' ? 'current-password' : 'new-password' });
    const code = h('input', { type: 'text', dir: 'ltr', maxLength: 40, placeholder: 'רק לבעלים בהפעלה הראשונה' });
    const server = h('input', { type: 'text', dir: 'ltr', value: settings.serverUrl });
    const err = h('p', { class: 'err', role: 'alert' });
    const status = h('p', { class: 'srv-status', role: 'status' }, 'בודק חיבור לשרת...');
    const submitBtn = h('button', { class: 'btn primary', type: 'submit' }, mode === 'login' ? 'התחברות' : 'יצירת חשבון');
    const checkServer = async () => {
      status.className = 'srv-status';
      status.textContent = 'בודק חיבור לשרת...';
      const saved = await L.saveSettings({ serverUrl: server.value });
      if (!saved.ok) { status.className = 'srv-status bad'; status.textContent = saved.error; return; }
      const r = await L.api({ method: 'GET', path: '/api/health' });
      if (r.ok) { status.className = 'srv-status ok'; status.textContent = 'השרת מחובר.'; }
      else { status.className = 'srv-status bad'; status.textContent = 'השרת לא עונה. הפעל אותו (npm start בתיקייה server) ובדוק את הכתובת.'; }
    };
    server.addEventListener('change', checkServer);
    const codeField = h('label', { class: 'field' }, h('span', null, 'קוד הקמה'), code);
    codeField.hidden = true;
    const form = h('form', {
      noValidate: true,
      on: {
        submit: async (e) => {
          e.preventDefault();
          err.textContent = '';
          submitBtn.disabled = true;
          submitBtn.textContent = 'מתחבר...';
          try {
            const saved = await L.saveSettings({ serverUrl: server.value });
            if (!saved.ok) { err.textContent = saved.error; return; }
            const body = { username: user.value.trim(), password: pass.value };
            if (mode === 'register' && code.value.trim()) body.setupCode = code.value.trim();
            const r = await L.api({ method: 'POST', path: mode === 'login' ? '/api/login' : '/api/register', body });
            if (!r.ok) { err.textContent = errText(r, 'ההתחברות נכשלה.'); return; }
            state.token = r.data.token;
            safeSet('token', state.token);
            state.me = r.data.me;
            start();
          } catch (ex) {
            err.textContent = 'שגיאה לא צפויה: ' + (ex && ex.message ? ex.message : ex);
          } finally {
            submitBtn.disabled = false;
            submitBtn.textContent = mode === 'login' ? 'התחברות' : 'יצירת חשבון';
          }
        }
      }
    },
    h('label', { class: 'field' }, h('span', null, 'שם משתמש'), user),
    h('label', { class: 'field' }, h('span', null, 'סיסמה'), pass),
    mode === 'register' ? codeField : null,
    h('label', { class: 'field' }, h('span', null, 'כתובת השרת'), server),
    status,
    err,
    submitBtn,
    mode === 'register' ? h('button', { class: 'link', type: 'button', on: { click: () => { codeField.hidden = !codeField.hidden; } } }, 'יש לי קוד הקמה') : null);
    card.append(
      h('img', { class: 'logo', src: 'logo.jpg', alt: '' }),
      h('h1', null, 'OGIL Reborn'),
      h('p', { class: 'sub' }, 'התחבר כדי להמשיך'),
      h('div', { class: 'tabs' },
        h('button', { type: 'button', class: mode === 'login' ? 'on' : '', on: { click: () => { mode = 'login'; render(); } } }, 'התחברות'),
        h('button', { type: 'button', class: mode === 'register' ? 'on' : '', on: { click: () => { mode = 'register'; render(); } } }, 'חשבון חדש')),
      form);
    user.focus();
    checkServer();
  };
  app.append(h('div', { class: 'stars' }), winCtl(), h('div', { class: 'auth-wrap' }, card));
  render();
}

/* ---------- start ---------- */

let pingTimer = null;
function start() {
  buildShell();
  go('home');
  clearInterval(pingTimer);
  pingTimer = setInterval(() => { if (state.token) api('POST', '/api/ping'); }, 60000);
}

async function boot() {
  if (!state.token) return showAuth();
  const r = await L.api({ method: 'GET', path: '/api/me', token: state.token });
  if (r.ok) {
    state.me = r.data;
    return start();
  }
  if (r.status === 0) {
    // Server not reachable: let the user fix the address instead of losing the login.
    await showAuth();
    toast(errText(r), true);
    return;
  }
  state.token = null;
  safeSet('token', null);
  showAuth();
}

boot();
