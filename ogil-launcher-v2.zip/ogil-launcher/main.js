const { app, BrowserWindow, ipcMain, shell, dialog } = require('electron');
const path = require('path');
const fs = require('fs');
const crypto = require('crypto');
const { spawn } = require('child_process');

const DEFAULT_SETTINGS = { serverUrl: 'http://localhost:3000', defaultArgs: '' };

function dataFile(name) {
  return path.join(app.getPath('userData'), name);
}
function readJson(name, fallback) {
  try {
    return JSON.parse(fs.readFileSync(dataFile(name), 'utf8'));
  } catch (e) {
    return fallback;
  }
}
function writeJson(name, value) {
  fs.mkdirSync(app.getPath('userData'), { recursive: true });
  fs.writeFileSync(dataFile(name), JSON.stringify(value, null, 2));
}

// launcher-config.json ships inside the app. Put your permanent server address there
// before building, so everyone who downloads the launcher connects without typing it.
function bundledDefaults() {
  try {
    const c = JSON.parse(fs.readFileSync(path.join(__dirname, 'launcher-config.json'), 'utf8'));
    return typeof c.serverUrl === 'string' && /^https?:\/\/\S+$/i.test(c.serverUrl) ? { serverUrl: c.serverUrl.replace(/\/+$/, '') } : {};
  } catch (e) {
    return {};
  }
}
const getSettings = () => Object.assign({}, DEFAULT_SETTINGS, bundledDefaults(), readJson('settings.json', {}));
const getLibrary = () => {
  const lib = readJson('library.json', []);
  return Array.isArray(lib) ? lib : [];
};

// Splits "-a 1 "two words"" into ["-a", "1", "two words"].
function splitArgs(text) {
  const out = [];
  const re = /"([^"]*)"|(\S+)/g;
  let m;
  while ((m = re.exec(text || ''))) out.push(m[1] !== undefined ? m[1] : m[2]);
  return out;
}

const isHttp = (u) => typeof u === 'string' && /^https?:\/\/\S+$/i.test(u);

function createWindow() {
  const win = new BrowserWindow({
    width: 1180,
    height: 720,
    minWidth: 980,
    minHeight: 620,
    frame: false,
    backgroundColor: '#050d36',
    title: 'OGIL Reborn Launcher',
    webPreferences: {
      preload: path.join(__dirname, 'preload.js'),
      contextIsolation: true,
      nodeIntegration: false,
      sandbox: true
    }
  });
  win.setMenu(null);
  win.loadFile(path.join(__dirname, 'renderer', 'index.html'));
  // Never let the app window navigate away or open new windows.
  win.webContents.setWindowOpenHandler(() => ({ action: 'deny' }));
  win.webContents.on('will-navigate', (e) => e.preventDefault());
}

/* ---------- window ---------- */
ipcMain.on('win:minimize', (e) => BrowserWindow.fromWebContents(e.sender)?.minimize());
ipcMain.on('win:close', (e) => BrowserWindow.fromWebContents(e.sender)?.close());

/* ---------- settings ---------- */
ipcMain.handle('settings:get', () => getSettings());
ipcMain.handle('settings:set', (_e, s) => {
  const next = getSettings();
  if (s && typeof s.serverUrl === 'string') {
    const url = s.serverUrl.trim().replace(/\/+$/, '');
    if (!isHttp(url)) return { ok: false, error: 'כתובת השרת צריכה להתחיל ב-http או https.' };
    next.serverUrl = url;
  }
  if (s && typeof s.defaultArgs === 'string') next.defaultArgs = s.defaultArgs.slice(0, 500);
  writeJson('settings.json', next);
  return { ok: true, settings: next };
});

/* ---------- talking to the server ---------- */
ipcMain.handle('api:request', async (_e, req) => {
  const base = getSettings().serverUrl;
  const method = ['GET', 'POST', 'PUT', 'DELETE'].includes(req && req.method) ? req.method : 'GET';
  if (!req || typeof req.path !== 'string' || !req.path.startsWith('/api/')) {
    return { ok: false, status: 0, data: { error: 'בקשה לא תקינה.' } };
  }
  try {
    const headers = { 'Content-Type': 'application/json' };
    if (typeof req.token === 'string' && req.token) headers.Authorization = 'Bearer ' + req.token;
    const res = await fetch(base + req.path, {
      method,
      headers,
      body: req.body !== undefined && method !== 'GET' ? JSON.stringify(req.body) : undefined,
      signal: AbortSignal.timeout(10000)
    });
    let data = null;
    try {
      data = await res.json();
    } catch (e) {
      data = null;
    }
    return { ok: res.ok, status: res.status, data };
  } catch (e) {
    return { ok: false, status: 0, data: { error: 'אין חיבור לשרת. בדוק את הכתובת בהגדרות.' } };
  }
});

/* ---------- your projects ---------- */
ipcMain.handle('library:list', () => getLibrary());

ipcMain.handle('library:add', (_e, p) => {
  if (!p || typeof p.name !== 'string' || !p.name.trim()) return { ok: false, error: 'חסר שם.' };
  const type = p.type === 'web' ? 'web' : 'exe';
  const target = typeof p.target === 'string' ? p.target.trim() : '';
  if (type === 'web' && !isHttp(target)) return { ok: false, error: 'הקישור צריך להתחיל ב-http או https.' };
  if (type === 'exe' && !target) return { ok: false, error: 'בחר את קובץ המשחק.' };
  const lib = getLibrary();
  if (lib.length >= 50) return { ok: false, error: 'יש יותר מדי פרויקטים בספרייה.' };
  lib.push({
    id: crypto.randomUUID(),
    name: p.name.trim().slice(0, 60),
    version: typeof p.version === 'string' ? p.version.trim().slice(0, 20) : '',
    type,
    target,
    args: typeof p.args === 'string' ? p.args.slice(0, 500) : ''
  });
  writeJson('library.json', lib);
  return { ok: true };
});

ipcMain.handle('library:remove', (_e, id) => {
  writeJson('library.json', getLibrary().filter((p) => p.id !== id));
  return { ok: true };
});

ipcMain.handle('library:launch', (_e, id) => {
  const p = getLibrary().find((x) => x.id === id);
  if (!p) return { ok: false, error: 'הפרויקט לא נמצא בספרייה.' };
  if (p.type === 'web') {
    if (!isHttp(p.target)) return { ok: false, error: 'הקישור לא תקין.' };
    shell.openExternal(p.target);
    return { ok: true };
  }
  if (!fs.existsSync(p.target)) return { ok: false, error: 'קובץ המשחק לא נמצא: ' + p.target };
  const args = splitArgs(getSettings().defaultArgs).concat(splitArgs(p.args));
  return new Promise((resolve) => {
    try {
      const child = spawn(p.target, args, { cwd: path.dirname(p.target), detached: true, stdio: 'ignore' });
      child.once('error', (err) => resolve({ ok: false, error: err.message }));
      child.once('spawn', () => {
        child.unref();
        resolve({ ok: true });
      });
    } catch (err) {
      resolve({ ok: false, error: err.message });
    }
  });
});

ipcMain.handle('dialog:pick', async (e) => {
  const win = BrowserWindow.fromWebContents(e.sender);
  const r = await dialog.showOpenDialog(win, {
    properties: ['openFile'],
    filters: [{ name: 'Game', extensions: ['exe', 'bat', 'cmd', 'lnk'] }, { name: 'All files', extensions: ['*'] }]
  });
  return r.canceled || !r.filePaths[0] ? null : r.filePaths[0];
});

ipcMain.handle('shell:open', (_e, url) => {
  if (!isHttp(url)) return { ok: false };
  shell.openExternal(url);
  return { ok: true };
});

app.whenReady().then(() => {
  createWindow();
  app.on('activate', () => {
    if (BrowserWindow.getAllWindows().length === 0) createWindow();
  });
});

app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') app.quit();
});
